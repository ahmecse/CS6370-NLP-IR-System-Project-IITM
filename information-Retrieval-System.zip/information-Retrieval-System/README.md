# Simple IRS system from scratch
A simple search engine developed using python
